const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('node:path');
const fs = require('node:fs');

let win;
let activeClient;

function createWindow() {
  win = new BrowserWindow({
    width: 1180,
    height: 790,
    minWidth: 850,
    minHeight: 650,
    backgroundColor: '#0b1020',
    title: 'Nova Launcher',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

function sendLog(line) {
  if (win && !win.isDestroyed()) win.webContents.send('nova:log', String(line));
}

ipcMain.handle('nova:launch', async (_event, config) => {
  if (activeClient) throw new Error('Запуск уже выполняется.');
  const username = String(config.username || '').trim();
  if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) {
    throw new Error('Ник: 3–16 латинских букв, цифр или _.');
  }
  const version = String(config.version || '1.20.1');
  if (!/^\d+\.\d+(\.\d+)?$/.test(version)) throw new Error('Некорректная версия.');
  const ram = Math.max(2, Math.min(12, Number(config.ram) || 4));
  const root = path.join(app.getPath('userData'), 'minecraft');

  try {
    // Use the stable CommonJS MCLC package; @mclc/main currently ships
    // a CommonJS build that Node interprets as ESM.
    const { Client } = require('minecraft-launcher-core');
    const launcher = new Client();

    // Minecraft's standard deterministic offline UUID.
    const hash = require('node:crypto')
      .createHash('md5')
      .update(`OfflinePlayer:${username}`, 'utf8')
      .digest();
    hash[6] = (hash[6] & 0x0f) | 0x30;
    hash[8] = (hash[8] & 0x3f) | 0x80;
    const uuidBytes = Buffer.from(hash);
    const offlineUuid = [
      uuidBytes.subarray(0, 4).toString('hex'),
      uuidBytes.subarray(4, 6).toString('hex'),
      uuidBytes.subarray(6, 8).toString('hex'),
      uuidBytes.subarray(8, 10).toString('hex'),
      uuidBytes.subarray(10, 16).toString('hex')
    ].join('-');

    activeClient = launcher;
    launcher.on('debug', (message) => sendLog(message));
    launcher.on('data', (message) => sendLog(Buffer.isBuffer(message) ? message.toString('utf8') : message));
    launcher.on('error', (message) => sendLog(`Ошибка игрового процесса: ${message}`));
    launcher.on('close', (code) => sendLog(`Minecraft завершился с кодом ${code}`));

    sendLog(`Подготовка Minecraft ${version}…`);
    sendLog(`Игровая папка: ${root}`);
    sendLog('При первом запуске будут загружены игровые файлы с серверов Minecraft.');
    sendLog('Офлайн-профиль не заменяет лицензионную авторизацию на серверах.');

    const options = {
      authorization: {
        access_token: '',
        client_token: '',
        uuid: offlineUuid,
        name: username,
        user_properties: '{}',
        meta: { type: 'mojang', demo: false }
      },
      root,
      version: { number: version, type: 'release' },
      memory: { max: `${ram}G`, min: '2G' }
    };
    const child = await launcher.launch(options);
    sendLog(child ? 'Команда запуска Minecraft передана игровому процессу.' : 'Команда запуска Minecraft обработана.');
    return { ok: true };
  } catch (err) {
    sendLog(`ОШИБКА: ${err && err.message ? err.message : String(err)}`);
    throw new Error('Не удалось установить или запустить Minecraft. Проверь журнал и Java. Подробности: ' + (err?.message || err));
  } finally {
    activeClient = null;
  }
});

ipcMain.handle('nova:open-game-folder', async () => {
  const folder = path.join(app.getPath('userData'), 'minecraft');
  fs.mkdirSync(folder, { recursive: true });
  await shell.openPath(folder);
  return folder;
});

const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('nova', {
  launch: (config) => ipcRenderer.invoke('nova:launch', config),
  openGameFolder: () => ipcRenderer.invoke('nova:open-game-folder'),
  onLog: (callback) => ipcRenderer.on('nova:log', (_event, line) => callback(line))
});
